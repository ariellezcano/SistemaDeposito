import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { FilRolComponent } from 'src/app/pages/component/filtro/fil-rol/fil-rol.component';
import { Rol } from 'src/app/model/index.model';
import { RolService } from 'src/app/service/index.service';
import { UturuncoUtils } from 'src/app/utils/uturuncoUtils';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-lst-rol',
  templateUrl: './lst-rol.component.html',
  styleUrls: ['./lst-rol.component.scss']
})
export class LstRolComponent implements OnInit {


  @ViewChild(FilRolComponent, { static: true }) fil: FilRolComponent;
  @ViewChild('close') cerrar: ElementRef;

  entity = 'rol';

  items: Rol[];
  item: Rol;

  proccess: Boolean;

  constructor(private wsdl: RolService, private router: Router) {
    this.item = new Rol();
    this.items = [];
  }

  ngOnInit() {

  }

  preNew() {
    this.item = new Rol();
  }

  select(item: Rol) {
    this.item = item;
  }

  cancel() {
    this.item = new Rol();
    this.fil.list();
  }

  async setResultCancel(event: boolean) {
    UturuncoUtils.showToas('Operación cancelada', 'info');
  }

  setResult(event: any) {
    this.cancel();
  }

  evento(event: Boolean) {
    UturuncoUtils.showToas('Se creo correctamente', 'success');
    this.cerrar.nativeElement.click();
    this.fil.list();
  }

  preDelete(item: Rol) {
    this.item = new Rol();
    this.item = item;

    Swal.fire({
      title: 'Esta Seguro?',
      text: '¡No podrás recuperar este archivo ' + item.nombre + '!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: '¡Eliminar!',
      cancelButtonText: 'Cancelar',
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
    }).then((result) => {
      if (result.value) {
        this.delete();
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        UturuncoUtils.showToas('Tu archivo esta seguro :)', 'warning');
      }
    });
  }

  async delete() {
    try {
      this.proccess = true;
      const res = await this.wsdl.doDelete(this.item.id).then();
      const result = JSON.parse(JSON.stringify(res));
      console.log(result);
      if (result.code == 200) {
        UturuncoUtils.showToas(result.msg, 'success');
        this.cancel();
      } else {
        UturuncoUtils.showToas(result.msg, 'error');
      }
    } catch (error) {
      UturuncoUtils.showToas('Excepción: ' + error.message, 'error');
    }
    this.proccess = false;
  }

  doFound(event: Rol[]) {
    this.items = event;

  }

  linkear(id?: Number) {
    this.router.navigateByUrl('dashboard/' + this.entity + '/abm/' + id);
  }



}
